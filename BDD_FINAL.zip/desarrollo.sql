USE cursosdb;

SHOW TABLES;

-- REGLAS DE INTEGRIDAD
-- 1. Correo único
ALTER TABLE estudiantes
ADD CONSTRAINT correo_unico UNIQUE (correo);

-- 2. Niveles permitidos
ALTER TABLE cursos
ADD CONSTRAINT nivel_valido
CHECK (nivel IN ('Basico', 'Intermedio', 'Avanzado'));

-- 3. Cupos entre 10 y 60
ALTER TABLE cursos
ADD CONSTRAINT cupos_validos
CHECK (cupos_disponibles BETWEEN 10 AND 60);

-- VISTA 1: ESTUDIANTES MATRICULADOS
CREATE VIEW vista_matriculas AS
SELECT
    CONCAT(e.nombre, ' ', e.apellido) AS estudiante,
    c.nombre AS curso,
    m.fecha_matricula,
    c.nivel
FROM matriculas m
INNER JOIN estudiantes e
    ON m.id_estudiante = e.id_estudiante
INNER JOIN cursos c
    ON m.id_curso = c.id_curso;

-- VISTA 2: CURSOS E INSTRUCTORES
CREATE VIEW vista_instructores AS
SELECT
    c.nombre AS curso,
    i.nombre AS instructor,
    i.especialidad
FROM cursos c
INNER JOIN instructores i
    ON c.id_instructor = i.id_instructor;

SELECT * FROM vista_matriculas;
SELECT * FROM vista_instructores;

-- USUARIOS Y PERMISOS
-- 1. Crear administrador
CREATE USER 'admin_cursos'@'localhost'
IDENTIFIED BY 'Admin12345!';

GRANT ALL PRIVILEGES ON cursosdb.*
TO 'admin_cursos'@'localhost';

-- 2. Crear usuario de consulta
CREATE USER 'consulta_cursos'@'localhost'
IDENTIFIED BY 'Consulta12345!';

-- 3. Permitir consultar solo las vistas
GRANT SELECT ON cursosdb.vista_matriculas
TO 'consulta_cursos'@'localhost';

GRANT SELECT ON cursosdb.vista_instructores
TO 'consulta_cursos'@'localhost';

-- 4. Comprobar permisos
SHOW GRANTS FOR 'admin_cursos'@'localhost';
SHOW GRANTS FOR 'consulta_cursos'@'localhost';

ALTER TABLE cursos
DROP CHECK cupos_validos;

ALTER TABLE cursos
ADD CONSTRAINT cupos_validos
CHECK (cupos_disponibles BETWEEN 0 AND 60);


-- TRIGGER 1: ELIMINAR MATRICULAS DE UN CURSO
DELIMITER //

CREATE TRIGGER eliminar_matriculas
BEFORE DELETE ON cursos
FOR EACH ROW
BEGIN
    DELETE FROM matriculas
    WHERE id_curso = OLD.id_curso;
END //

DELIMITER ;


-- TRIGGER 2: DESCONTAR UN CUPO
DELIMITER //

CREATE TRIGGER descontar_cupo
AFTER INSERT ON matriculas
FOR EACH ROW
BEGIN
    UPDATE cursos
    SET cupos_disponibles = cupos_disponibles - 1
    WHERE id_curso = NEW.id_curso;
END //

DELIMITER ;


-- PRUEBA DEL TRIGGER DE CUPOS
START TRANSACTION;

SELECT cupos_disponibles
FROM cursos
WHERE id_curso = 1;

INSERT INTO matriculas
(id_estudiante, id_curso, fecha_matricula)
VALUES (3, 1, '2026-11-10');

SELECT cupos_disponibles
FROM cursos
WHERE id_curso = 1;

ROLLBACK;


-- PRUEBA DEL TRIGGER DE ELIMINACION
START TRANSACTION;

SELECT COUNT(*) AS matriculas
FROM matriculas
WHERE id_curso = 1;

DELETE FROM cursos
WHERE id_curso = 1;

SELECT COUNT(*) AS matriculas
FROM matriculas
WHERE id_curso = 1;

ROLLBACK;

-- PRUEBA DEL TRIGGER DE DESCUENTO DE CUPOS
START TRANSACTION;

SELECT cupos_disponibles FROM cursos WHERE id_curso = 1;

INSERT INTO matriculas (id_estudiante, id_curso, fecha_matricula)
VALUES (3, 1, '2026-11-10');

SELECT cupos_disponibles FROM cursos WHERE id_curso = 1;

ROLLBACK;

-- VERIFICAR CUPOS Y MATRICULAS
SELECT c.id_curso, c.nombre, c.cupos_disponibles,
       COUNT(m.id_matricula) AS matriculados
FROM cursos c
LEFT JOIN matriculas m
ON c.id_curso = m.id_curso
GROUP BY c.id_curso, c.nombre, c.cupos_disponibles;

